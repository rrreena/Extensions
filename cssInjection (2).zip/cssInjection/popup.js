document.addEventListener('DOMContentLoaded', () => {
    const toggleButton = document.getElementById('toggle-btn');

    // Get the current dark mode status from chrome storage
    chrome.storage.sync.get('darkModeEnabled', (data) => {
        const isDarkMode = data.darkModeEnabled || false;
        updateButton(isDarkMode);
    });

    // Toggle dark mode on button click
    toggleButton.addEventListener('click', () => {
        chrome.storage.sync.get('darkModeEnabled', (data) => {
            const isDarkMode = data.darkModeEnabled || false;
            const newMode = !isDarkMode;
            chrome.storage.sync.set({ 'darkModeEnabled': newMode });
            updateButton(newMode);
            sendMessage(newMode);
        });
    });

    // Update button text based on the mode
    function updateButton(isDarkMode) {
        if (isDarkMode) {
            toggleButton.textContent = 'Light Mode';
        } else {
            toggleButton.textContent = 'Dark Mode';
        }
    }

    // Send a message to background script to toggle dark mode
    function sendMessage(isDarkMode) {
        if (isDarkMode) {
            chrome.runtime.sendMessage({ action: 'darkmode-on' });
        } else {
            chrome.runtime.sendMessage({ action: 'darkmode-off' });
        }
    }
});
