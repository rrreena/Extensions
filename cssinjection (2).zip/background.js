// depending on whether b is true or false, send a message indicating whether to set the background to darkmode-on or darkmode-off 

// chrome.storage.set({"darkModeEnabled": false});

// let b = false;
// chrome.runtime.onMessage.addListener(function(message) {

//   if (message.action === "change-boolean"){
//     b = !b;
//     console.log(b);

//     if (b) {
//       chrome.runtime.sendMessage({action: 'darkmode-on'});
//     }
//     else {
//       chrome.runtime.sendMessage({action: 'darkmode-off'});
//     }

//     setdarkmode(b)
//   }
// );


// // listen for changes in the storage
// chrome.storage.onChanged.addListener((changes, namespace) => {
//   if(changes=="darkModeEnabled") {

//     chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
//       chrome.scripting.executeScript({
//         target: {tabId: tabs[0].id},
//         function: setdarkmode,
//         args: b
//       })
//     });
    
//   }
// });
//dossssss
function setdarkmode(){
  //if (enabled){

    let css = `
        body, html {
    background-color: #000000 !important;
    color: #ffffff !important;
    font-family: Arial, sans-serif !important;
}

a {
    color: #1e90ff !important; /* Bright blue for links */
}

a:hover {
    color: #82b1ff !important; /* Lighter hover state for links */
}

/* General Layout */
header, footer, .navbar, .sidebar {
    background-color: #2c2c2c !important; /* Dark gray for headers and footers */
    color: #ffffff !important;
}

section, article, aside, .container, .content {
    background-color: #1e1e1e !important;
    color: #e0e0e0 !important;
    border: 1px solid #333333 !important;
}

.card, .panel, .widget {
    background-color: #1f1f1f !important;
    border: 1px solid #444444 !important;
}

/* Inputs and Forms */
input, textarea, button, select {
    background-color: #333333 !important;
    color: #ffffff !important;
    border: 1px solid #555555 !important;
}

input::placeholder, textarea::placeholder {
    color: #bbbbbb !important;
}

input[type="checkbox"], input[type="radio"] {
    background-color: #444444 !important;
    border-color: #777777 !important;
}

button:hover, input[type="submit"]:hover {
    background-color: #555555 !important;
    color: #ffffff !important;
}

/* Tables */
table {
    background-color: #1c1c1c !important;
    border: 1px solid #333333 !important;
    color: #e0e0e0 !important;
}

th, td {
    padding: 10px !important;
    border: 1px solid #333333 !important;
}

th {
    background-color: #2e2e2e !important;
}

tr:nth-child(even) {
    background-color: #292929 !important;
}

/* Modals, Dialogs */
.modal, .dialog {
    background-color: #222222 !important;
    border: 1px solid #444444 !important;
    color: #e0e0e0 !important;
}

/* Tooltips */
.tooltip {
    background-color: #333333 !important;
    color: #ffffff !important;
    border-radius: 3px !important;
    padding: 5px !important;
}

/* Buttons */
.btn-primary {
    background-color: #1e90ff !important;
    border: 1px solid #1a73e8 !important;
}

.btn-primary:hover {
    background-color: #357ae8 !important;
}

/* Navigation Menus */
.navbar, .menu {
    background-color: #1e1e1e !important;
    color: #e0e0e0 !important;
}

.dropdown-menu {
    background-color: #333333 !important;
    color: #ffffff !important;
}

.dropdown-menu a {
    color: #1e90ff !important;
}

.dropdown-menu a:hover {
    color: #ffffff !important;
    background-color: #1a1a1a !important;
}

/* Media (Images, Videos, Iframes) */
img, video, iframe {
    background-color: #000000 !important;
    border: 1px solid #333333 !important;
}

img {
    filter: brightness(0.85) !important;
}

video {
    filter: brightness(0.85) !important;
}

/* Code Blocks */
.code, pre {
    background-color: #2a2a2a !important;
    color: #e0e0e0 !important;
    padding: 10px !important;
    border-radius: 5px !important;
    overflow: auto !important;
}

/* Forms */
form {
    background-color: #1e1e1e !important;
    border: 1px solid #333333 !important;
    padding: 20px !important;
    border-radius: 5px !important;
}

/* Alerts */
.alert {
    background-color: #2c2c2c !important;
    border: 1px solid #444444 !important;
    color: #ffffff !important;
}

/* Progress Bars */
progress {
    background-color: #555555 !important;
    color: #ffffff !important;
}

/* Lists */
ul, ol {
    background-color: #1e1e1e !important;
    color: #e0e0e0 !important;
}

li {
    border-bottom: 1px solid #333333 !important;
}

/* Highlighting and Selection */
::selection {
    background-color: #555555 !important;
    color: #ffffff !important;
}

.highlight {
    background-color: #555555 !important;
}

@media (prefers-color-scheme: dark) {
    body {
        background-color: #000000;
        color: #ffffff;
    }
    /* Your dark mode CSS rules */
}


    `;


    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      let tab = tabs[0];

      // chrome.scripting.executeScript({
      //   target: {tabId: tab.id},
      //   func: () =>{
      //     const stylesheets = document.querySelectorAll('link[rel="stylesheet"], style');
      //     stylesheets.forEach(style => style.remove());
      //   }
      // });
      
      chrome.scripting.insertCSS({
        target: {tabId: tab.id},
        css: css
      });
    });
  //}
}

chrome.tabs.onActivated.addListener(() => setdarkmode());
chrome.tabs.onCreated.addListener(() => setdarkmode());
chrome.tabs.onUpdated.addListener(() => setdarkmode());