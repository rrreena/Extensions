// depending on whether b is true or false, send a message indicating whether to set the background to darkmode-on or darkmode-off 

chrome.storage.set({"darkModeEnabled": false});

let b = false;
chrome.runtime.onMessage.addListener(function(message) {

  if (message.action === "change-boolean"){
    b = !b;
    console.log(b);

    if (b) {
      chrome.runtime.sendMessage({action: 'darkmode-on'});
    }
    else {
      chrome.runtime.sendMessage({action: 'darkmode-off'});
    }

    setdarkmode(b)

  }
  
// });


// // listen for changes in the storage
// chrome.storage.onChanged.addListener((changes, namespace) => {
//   if(changes=="darkModeEnabled") {

//     chrome.tabs.query({active: true, currentWindow: true}, function (tabs) {
//       chrome.scripting.executeScript({
//         target: {tabId: tabs[0].id},
//         function: setdarkmode,
//         args: b
//       })
//     });
    
//   }
// });

function setdarkmode(){
  //if (enabled){
    let css = `
        body {
            background-color: #000000 !important;
            color: #ffffff !important;
            font-family: Arial, sans-serif !important;
          }
          a {
            color: #1e90ff !important; /* Bright blue for links */
          }
          header, footer, .navbar, .sidebar {
            background-color: #2c2c2c !important; /* Dark gray for headers and footers */
            color: #ffffff !important;
          }
          .card, .panel, .container {
            background-color: #1e1e1e !important; /* Slightly lighter gray for cards and panels */
            border: 1px solid #333333 !important;
          }
          input, textarea, button {
            background-color: #333333 !important;
            color: #ffffff !important;
            border: 1px solid #555555 !important;
          }
          /* Additional styles for specific elements if needed */
          .highlight {
            background-color: #555555 !important;
          }
          .code {
            background-color: #2a2a2a !important;
            color: #e0e0e0 !important;
            padding: 10px;
            border-radius: 5px;
          }
    `;

    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      let tab = tabs[0];
      
      chrome.scripting.insertCSS({
        target: {tabId: tab.id},
        css: css
      });
    })
  //}
}

chrome.tabs.onActivated.addListener(setdarkmode());
chrome.tabs.onCreated.addListener(setdarkmode());
chrome.tabs.onUpdated.addListener(setdarkmode());