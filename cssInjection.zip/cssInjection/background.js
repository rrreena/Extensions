// Listen for messages from popup.js to apply dark mode
chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'darkmode-on') {
      setdarkmode(true);
    } else if (message.action === 'darkmode-off') {
      setdarkmode(false);
    }
  });

function setdarkmode(isDarkMode){
    
    // ADD THE FOLLOWING IF YOU WOULD LIKE ALL ITEMS TO BE DARK GREY!!!

    // * {
    // background-color: #2e2e2e !important;
    // }

    let css = `
    body, html {
        background-color: #2e2e2e !important;
    }
        * {
    color: #ffffff !important; /* Make all text white */
}
`;


    chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
      let tab = tabs[0];
      if(isDarkMode){
      chrome.scripting.insertCSS({
        target: {tabId: tab.id},
        css: css
      });
    }else {
        chrome.scripting.removeCSS({
          target: { tabId: tab.id },
          css: css
        });
      }
    });
  //}
}

// Check storage on tab activation or update to apply the correct theme
chrome.tabs.onActivated.addListener(() => applyStoredTheme());
chrome.tabs.onUpdated.addListener(() => applyStoredTheme());

function applyStoredTheme() {
  chrome.storage.sync.get('darkModeEnabled', (data) => {
    const isDarkMode = data.darkModeEnabled || false;
    setdarkmode(isDarkMode);
  });
}