// create listeners to listen for darkmode-on or darkmode-off, and depending on which one pass a boolean variable to the setdarkmode() function

document.getElementById("color").addEventListener('click', function (){

  //chrome.runtime.sendMessage({action: 'change-boolean'});

  // get data out of chrome storage
  chrome.storage.get('darkModeEnabled', function (boolean){
      chrome.storage.set({'darkModeEnabled':!boolean});
  });
  
});

chrome.runtime.onMessage.addListener(function(message) {
  if (message.action === 'darkmode-on') {
    
    setdarkmode(true);
  }
  if (message.action === 'darkmode-off') {
    setdarkmode(false);
  }
})